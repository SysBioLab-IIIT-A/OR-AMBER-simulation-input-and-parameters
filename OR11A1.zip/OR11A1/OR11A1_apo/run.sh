#!/bin/bash
export CUDA_VISIBLE_DEVICES="0"
amber="pmemd.cuda"

init="step5_input"
mini_prefix="step6.0_minimization"
equi_prefix="step6.%d_equilibration"
prod_prefix="step7_production"
prod_step="step7"

# Minimization
if [ -e "dihe.restraint" ]; then
    sed -e "s/FC/250.0/g" dihe.restraint > "${mini_prefix}.rest"
fi

"${amber}" -O -i "${mini_prefix}.mdin" -p "${init}.parm7" -c "${init}.rst7" -o "${mini_prefix}.mdout" -r "${mini_prefix}.rst7" -inf "${mini_prefix}.mdinfo" -ref "${init}.rst7"



# Equilibration
cnt=1
cntmax=6
fc=('250.0' '100.0' '50.0' '50.0' '25.0')

while [ ${cnt} -le ${cntmax} ]; do
    pcnt=$((cnt - 1))
    istep=$(printf "${equi_prefix}" ${cnt})
    pstep=$(printf "${equi_prefix}" ${pcnt})
    if [ ${cnt} -eq 1 ]; then
        pstep="${mini_prefix}"
    fi

    if [ -e "dihe.restraint" ] && [ ${cnt} -lt ${cntmax} ]; then
        sed -e "s/FC/${fc[${cnt}]}/g" dihe.restraint > "${istep}.rest"
    fi

    "${amber}" -O -i "${istep}.mdin" -p "${init}.parm7" -c "${pstep}.rst7" -o "${istep}.mdout" -r "${istep}.rst7" -inf "${istep}.mdinfo" -ref "${init}.rst7" -x "${istep}.nc"
    cnt=$((cnt + 1))
done



# Production
cnt=1
cntmax=1

while [ ${cnt} -le ${cntmax} ]; do
    pcnt=$((cnt - 1))
    istep="${prod_step}_${cnt}"
    pstep="${prod_step}_${pcnt}"
    if [ ${cnt} -eq 1 ]; then
        pstep=$(printf "${equi_prefix}" 6)
    fi

    "${amber}" -O -i "${prod_prefix}.mdin" -p "${init}.parm7" -c "${pstep}.rst7" -o "${istep}.mdout" -r "${istep}.rst7" -inf "${istep}.mdinfo" -x "${istep}.nc"
    cnt=$((cnt + 1))
done
